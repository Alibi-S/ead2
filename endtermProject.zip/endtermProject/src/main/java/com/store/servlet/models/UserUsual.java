package com.store.servlet.models;

public class UserUsual extends User{
    public UserUsual(String login, String password) {
        super(login, password);
    }
    public UserUsual(int id, String login, String password) {
        super(id, login, password);
    }
    public UserUsual(int id, String login, String password, double balance) {
        super(id, login, password, balance);
    }
}
