package com.store.servlet.servlets;

import com.store.servlet.configs.DatabaseConnection;
import com.store.servlet.models.User;
import com.store.servlet.models.UserAdmin;
import com.store.servlet.models.UserUsual;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/auth")
    public class AuthServlet extends javax.servlet.http.HttpServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();

        String login = req.getParameter("login");
        String password = req.getParameter("password");

        Connection connection = DatabaseConnection.getConnection();

        Statement stmt = null;
        try {
            stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM USERS WHERE user_login like '" + login + "'");

            User user = null;

            while (rs.next()){
                if(login.equals("admin")){
                    user = new UserAdmin(
                            Integer.parseInt(rs.getString("user_id")),
                            rs.getString("user_login"),
                            rs.getString("user_password"),
                            Double.parseDouble(rs.getString("user_balance")));
                } else {
                    user = new UserUsual(
                            Integer.parseInt(rs.getString("user_id")),
                            rs.getString("user_login"),
                            rs.getString("user_password"),
                            Double.parseDouble(rs.getString("user_balance")));
                }
            }

            if(user != null){
                if(password.equals(user.getPassword())){
                    session.setAttribute("user", user);
                    getServletContext().getRequestDispatcher("/index.jsp").forward(req, resp);
                }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        resp.sendRedirect("/auth.jsp");
    }
}
