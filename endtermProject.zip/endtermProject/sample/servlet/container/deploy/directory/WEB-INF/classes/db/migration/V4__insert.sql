insert into orders(order_id, user_id, product_id, user_login, product_name)
values(1, 1, 1, 'alish', 'CSGO');
insert into orders(order_id, user_id, product_id, user_login, product_name)
values(2, 2, 1, 'karina', 'CSGO');
insert into orders(order_id, user_id, product_id, user_login, product_name)
values(3, 3, 2, 'alibi', 'Dota 2');