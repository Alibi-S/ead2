insert into users(user_id, user_login, user_password, user_balance)
values(1, 'alish', 'alish1234', 2000);
insert into users(user_id, user_login, user_password, user_balance)
values(2, 'karina', '1234', 10000);
insert into users(user_id, user_login, user_password, user_balance)
values(3, 'alibi', '0000', 5000);
insert into users(user_id, user_login, user_password, user_balance)
values(4, 'admin', 'admin', 50000);