insert into products(product_id, product_name, product_desc, product_quantity, product_price)
values(1, 'CSGO', 'online shooter', 1000, 5000);
insert into products(product_id, product_name, product_desc, product_quantity, product_price)
values(2, 'Dota 2', 'online MMO', 2000, 2000);